package tmp;
//abstract class can contain 0..* normal and 0..* abstract method 
abstract class Sort{
	public void m1(){
		System.out.println("in tmp - m1");
	}
	public abstract  void sort();
}

class ShellSort extends Sort{

	@Override
	public void sort() {
		System.out.println("ShellSort");
	}
}
public class Lab1 {

	public static void main(String[] args) {
	ShellSort ssort = new ShellSort();
	ssort.sort();
	}
}
