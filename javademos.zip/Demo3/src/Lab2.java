class Tmp{
	
	public void m1(){
		System.out.println("m1 of tmp");
	}
	final public void m2(){
		System.out.println("m2 of tmp");
	}
}

 class Tmp1 extends Tmp{
	public void m1(){
		System.out.println("m1 of tmp1");
	}
	
}

public class Lab2 {
	public static void main(String[] args) {
		Tmp1 t1 =new Tmp1();
		t1.m1();
		t1.m2();
	}
}

