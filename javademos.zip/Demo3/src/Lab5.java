interface Sort {
	public void dosort();
}
interface Print {
	public void print();
}
class Bubble implements Sort,Print{
	@Override
	public void dosort() {
		System.out.println("Bubble - dosort");
	}

	@Override
	public void print() {
		System.out.println("Bubble - print");
	}
}
class Shell implements Sort{
	@Override
	public void dosort() {
		System.out.println("Shell - dosort");
	}

}
public class Lab5 {

	public static void main(String[] args) {
		String ch ="s";
		Bubble b = new Bubble();
		Shell sh = new Shell();
		Print pr = new Bubble();
		pr.print();
		Sort s = new Bubble();
		s.dosort();
		
		Sort sort = null;
		if (ch.equals("b"))
			sort = new Bubble();
		else
			 sort  = new Shell();
		sort.dosort();
	}

}
