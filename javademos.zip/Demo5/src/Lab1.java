import java.util.Scanner;

class Test extends Thread{
	private String str;
	 public Test(String str) {
		 this.str = str;
	}
	@Override
	public void run() {
		for (int i  = 0;i< 500;i++){
			System.out.print(str);
			if ((i %80)==0)
				System.out.println();
		}
	}
}

public class Lab1 {
public static void main(String[] args) {
	System.out.println("in start of main");
	Test t1 = new Test(".");
	Test t2 = new Test("-");
	Test t3 = new Test("xx");
	t1.start();
	t2.start();
	t3.start();
	try {
		Thread.sleep(10);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("end of main");
	
}
}
