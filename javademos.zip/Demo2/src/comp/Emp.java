package comp;
public class Emp{

	 int empno;
	protected String ename;
	
	public Emp(){
		System.out.println("Emp Constructor");
	}
	public void m1(){
		System.out.println("in m1 of Emp");
	}
}
