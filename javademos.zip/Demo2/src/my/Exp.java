package my;

import comp.Emp;

public class Exp {
void	m1(){
		Emp e = new Emp();
	
	}

}
