class Data{
	String str1;
	String str2;
}
public class Lab6 {
	int no1 =10;
	void prString(String i, String j){
		System.out.println("start of prString " + i  + ",   " + j);
		i+= 10;
		j+= 10;
		System.out.println("end of prString " + i  + ",   " + j);
	}
	void prData(Data i){
		System.out.println("start of prData " + i.str1 + ", "  +  i.str2  );
		i.str1+= 10;
		i.str2 +=100;
		System.out.println("i" + i);	
		i = new Data();
		System.out.println("i" + i);	
		System.out.println("end of prData " +i.str1 + ", "  +  i.str2  );
	}
public static void main(String[] args) {
	
	Lab6 lab =  new Lab6();
	String no1 = "AAA";
	String no2 = "bbbb";
	System.out.println("before prString, values of  no1 = "+ no1 +", no2 = " + no2);
	lab.prString(no1, no2);
	System.out.println("before prString, values of  no1 = "+ no1 +", no2 = " + no2);
	Data d1 =  new Data();
	System.out.println("d1" + d1 );
	d1.str1="A";
	d1.str2="B";
	System.out.println("before of prdata " +d1.str1 + ", "  +  d1.str2  );
	lab.prData(d1);
	System.out.println("before of prdata " +d1.str1 + ", "  +  d1.str2  );
}
}
