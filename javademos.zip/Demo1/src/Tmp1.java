import java.util.Arrays;
import java.util.Scanner;

public class Tmp1 {
	 public static void main(String args[])
	 {
		 Scanner sc=new Scanner(System.in);
		 String arr[]=new String[5];
		 int sum=0;
		 System.out.println("Enter the Names..");
		 for(int i=0;i<5;i++)
		 {
			 System.out.println("Enter Name " + (i+1));
			 arr[i]=sc.next();
			 sum+=arr[i].length();
		 }
		 System.out.println(Arrays.toString(arr));
		 System.out.println("Sum : " + sum);
		 System.out.println("Average : " + (sum/5));
		 sc.close();
	 }
	 
	}

