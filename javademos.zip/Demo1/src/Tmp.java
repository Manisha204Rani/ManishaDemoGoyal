import java.util.Scanner;

public class Tmp {

	public static void main(String[] args) {
		int a = 0, b = 1;
		int c = 0;

		Scanner scanner = new Scanner(System.in);
		System.out.println("How many numbers");
		int n = scanner.nextInt();
		if (n >= 1)
			System.out.print(a);
		if (n >= 2)
			System.out.print(" " + b);

		for (int i = 0; i < n - 2; i++) {
			c = a + b;
			a = b;
			b = c;
			System.out.print(" " + c);
		}

	}

}
