import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) 
	{
		short sh = 32760;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter a number ");
		short sh1 = scanner.nextShort();
	//	sh = sh + sh1;
		System.out.println("Short value = " + sh1);
	}

}
