package my;
import comp.Emp;
class Fresher extends Emp{
	public Fresher() {
		System.out.println("Fresher Constructor");
	}
	protected int college;
@Override
public void m1() {
	super.m1();
	System.out.println("in m1 of Fresher");

}
	public void m2(){
		System.out.println("in m2 of Fresher");
	}
}


public class Lab1 {

	public static void main(String[] args) {
		Fresher fresher = new Fresher();
		fresher.m1();
		fresher.m2();
		System.out.println(fresher);
	}

}
