package deptasgn;

public class DeptManager {
	private Dept[] deptarr= new Dept[5];
	public void modify(int i, Dept d)
	{	deptarr[i]= d;
	}
	public void print(){
		for(int i = 0;i <deptarr.length;i++){
			System.out.println(deptarr[i]);
		}
	}
	
	public static void main(String[] args) {
		/*create a instance of Deptmanager
		invoke modify for 0,2,3,4
		print */ 
		DeptManager mgr = new DeptManager();
		Dept d1= new Dept(10,"HR","Pnq");
		
		Dept d3= new Dept(30,"Fin","Blr");
		Dept d4= new Dept(40,"IT","Del");
		mgr.modify(0, d1);
		mgr.modify(2, new Dept(20,"Tra","Hyd"));
		mgr.modify(6, d3);
		mgr.modify(4, d4);
		mgr.print();
		
		

	}

}
