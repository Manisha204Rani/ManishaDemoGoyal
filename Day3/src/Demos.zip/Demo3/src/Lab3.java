class Base1{
	protected void m1(){
		
	}
	public void m2(){
		
	}
	
}
class Base2{
	protected void m1(){
	}
	public void m2(){
	}
	
}
class Derived1 extends Base1{
	public void m3(){
		
	}
}
public class Lab3 {
public static void main(String[] args) {
	Derived1 der  = new Derived1();
	der.m1();
	der.m2();
	der.m3();
	
}
}
